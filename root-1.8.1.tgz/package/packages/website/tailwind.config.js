export default {
	important: '#root',
}
