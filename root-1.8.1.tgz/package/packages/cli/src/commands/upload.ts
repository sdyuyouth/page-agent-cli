import { existsSync } from 'node:fs'
import { resolve } from 'node:path'
import type { Command } from 'commander'

import { getPageController } from '../context.js'
import { die, printSuccess } from '../output.js'

export function registerUpload(program: Command): void {
	program
		.command('upload <index> <files...>')
		.description('Set local file(s) on a <input type="file"> element by index.')
		.addHelpText(
			'after',
			`
Examples:
  $ page-agent-cli --json state                          # observe → find file input index
  $ page-agent-cli --json upload 5 /path/to/photo.jpg   # single file
  $ page-agent-cli --json upload 5 img1.png img2.png     # multiple files (relative paths OK)

Notes:
  The element at <index> must be an <input type="file">. Obtain the index from
  the most recent \`state\` snapshot. Relative paths are resolved against the
  current working directory.

  The browser fires the normal change/input events after injection, so upload
  handlers trigger exactly as if the user had used the system file picker.`
		)
		.action(async (indexStr: string, files: string[]) => {
			const index = parseInt(indexStr, 10)
			if (isNaN(index) || index < 0) die(`Invalid index: ${indexStr}`)

			// Resolve to absolute paths and validate existence.
			const resolvedPaths: string[] = []
			for (const f of files) {
				const abs = resolve(f)
				if (!existsSync(abs)) {
					die(`File not found: ${abs}`)
				}
				resolvedPaths.push(abs)
			}

			try {
				const pc = await getPageController()
				const result = await pc.uploadFiles(index, resolvedPaths)
				if (!result.success) die(result.message)
				printSuccess(result.message)
			} catch (err) {
				die(err)
			}
		})
}
